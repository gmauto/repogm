#!/bin/bash
#spark-submit --master yarn --class om.chance.bigdata.format.Format bigdata.jar
#spark-submit --master spark://hadoop1:7077 --class om.chance.bigdata.format.Format bigdata.jar
#spark-submit --master local --class om.chance.bigdata.format.Format bigdata.jar utf-8 >> localspark.log
#spark-submit --master local --class om.chance.bigdata.format.Format bigdata.jar GBK utf-8 > localspark.log
#spark-submit --master local --class om.chance.bigdata.format.Format bigdata.jar GBK GBK > localspark1.log
#spark-submit --master local --class om.chance.bigdata.format.Format bigdata.jar utf-8 utf-8 > localspark2.log
#spark-submit --master local --class om.chance.bigdata.format.Format bigdata.jar utf-8 GBK > localspark3.log
#spark-submit --master local --class com.spark.format.Format bigSpark.jar > log/spark_log_1

#spark-submit --master local --class com.chance.checkdata.Transform   checkdata-1.0.jar set.propertise > log/checkdata.log
#date=201704_201707
dir_home="/home/ipsos_test4/general"
function checkdata_claim() {
date=$1
num=20
name=claim
dir=`pwd`
echo ${dir}
#spark-submit --master local --class com.chance.checkdata.GBKToUTF_8 checkdata-1.0.jar ${dir_home}/data/${name}/${date}/${name}.csv ${dir}/log/${name}/${name}.dat_log
iconv -f GBK -t UTF-8 -c ${dir_home}/data/${name}/${date}/${name}.csv > ${dir}/log/${name}/${name}.dat_log
cat ${dir}/log/${name}/${name}.dat_log | awk -F "\",\"" '{print NF}'  > ${dir}/log/${name}/${name}_lines
cat ${dir}/log/${name}/${name}_lines | sort |uniq -c > ${dir}/log/${name}/claim_uniq
cat ${dir}/log/${name}/${name}_uniq | awk -F ' ' '$2<$num{print $0}' > ${dir}/log/${name}.error
claim_head_tt=$(cat ${dir}/lib/claim/claim_head | head -1)
claim_head=$(cat ${dir}/log/claim/claim.dat_log | head -1) 
arr=(${claim_head//,/ })
arrtt=(${claim_head_tt//,/ })
len=`echo ${claim_head} | awk -F "," "{print NF}"`
echo ${len}
echo ${#arr[*]}
echo "" > ${dir}/log/${name}/check_head.log
for((i=0;i<${#arr[*]};i++))
do
if [ "${arr[$i]}" == "${arrtt[$i]}" ]
then
 echo $i : "ok" >> ${dir}/log/${name}/check_head.log
else
 echo $i : "data "${arr[$i]} "-------->""file" ${arrtt[$i]} >> ${dir}/log/${name}/check_head.log
fi
done
}

function checkdata_part() {
date=$1
num=27
name=part
dir=`pwd`
echo ${dir}
iconv -f GBK -t UTF-8 -c ${dir_home}/data/${name}/${date}/${name}.csv > ${dir}/log/${name}/${name}.dat_log
#spark-submit --master local --driver-memory 10g --driver-cores 2 --executor-memory 4g --num-executors 4 --class com.chance.checkdata.GBKToUTF_8 checkdata-1.0.jar ${dir_home}/data/${name}/${date}/${name}.csv ${dir}/log/${name}/${name}.dat_log
cat ${dir}/log/${name}/${name}.dat_log | awk -F "\",\"" '{print NF}'  > ${dir}/log/${name}/${name}_lines
cat ${dir}/log/${name}/${name}_lines | sort |uniq -c > ${dir}/log/${name}/${name}_uniq
cat ${dir}/log/${name}/${name}_uniq | awk -F ' ' '$2<$num{print $0}' > ${dir}/log/${name}.error
part_head_tt=$(cat ${dir}/lib/part/part_head | head -1)
#echo ${part_head_tt}
part_head=$(cat ${dir}/log/part/part.dat_log | head -1)
#echo ${part_head}
arr=(${part_head//,/ })
arrtt=(${part_head_tt//,/ })
len=`echo ${part_head} | awk -F "," "{print NF}"`
echo ${len}
echo ${#arr[*]}
echo "" > ${dir}/log/${name}/check_head.log
for((i=0;i<${#arr[*]};i++))
do
if [ "${arr[$i]}" == "${arrtt[$i]}" ]
then
 echo $i : "ok" >> ${dir}/log/${name}/check_head.log
else
 echo $i : "data "${arr[$i]} "-------->""file" ${arrtt[$i]} >> ${dir}/log/${name}/check_head.log
fi
done
}

function checkdata_order() {
date=$1
num=37
name=order
dir=`pwd`
echo ${dir}
#spark-submit --master local --class com.chance.checkdata.GBKToUTF_8 checkdata-1.0.jar ${dir_home}/data/${name}/${date}/${name}.csv ${dir}/log/${name}/${name}.dat_log
iconv -f GBK -t UTF-8 -c ${dir_home}/data/${name}/${date}/${name}.csv > ${dir}/log/${name}/${name}.dat_log
cat ${dir}/log/${name}/${name}.dat_log | awk -F "\",\"" '{print NF}'  > ${dir}/log/${name}/${name}_lines
cat ${dir}/log/${name}/${name}_lines | sort |uniq -c > ${dir}/log/${name}/order_uniq
cat ${dir}/log/${name}/${name}_uniq | awk -F ' ' '$2<$num{print $0}' > ${dir}/log/${name}.error
order_head_tt=$(cat ${dir}/lib/order/order_head | head -1)
order_head=$(cat ${dir}/log/order/order.dat_log | head -1)
arr=(${order_head//,/ })
arrtt=(${order_head_tt//,/ })
len=`echo ${order_head} | awk -F "," "{print NF}"`
echo ${len}
echo ${#arr[*]}
echo "" > ${dir}/log/${name}/check_head.log
for((i=0;i<${#arr[*]};i++))
do
if [ "${arr[$i]}" == "${arrtt[$i]}" ]
then
 echo $i : "ok" >> ${dir}/log/${name}/check_head.log
else
 echo $i : "data "${arr[$i]} "-------->""file" ${arrtt[$i]} >> ${dir}/log/${name}/check_head.log
fi
done
}

function checkdata_customer() {
date=$1
num=48
name=customer
dir=`pwd`
echo ${dir}
#spark-submit --master local --class com.chance.checkdata.GBKToUTF_8 checkdata-1.0.jar ${dir_home}/data/${name}/${date}/${name}.csv ${dir}/log/${name}/${name}.dat_log
iconv -f GBK -t UTF-8 -c ${dir_home}/data/${name}/${date}/${name}.csv > ${dir}/log/${name}/${name}.dat_log
cat ${dir}/log/${name}/${name}.dat_log | awk -F "\",\"" '{print NF}'  > ${dir}/log/${name}/${name}_lines
cat ${dir}/log/${name}/${name}_lines | sort |uniq -c > ${dir}/log/${name}/${name}_uniq
cat ${dir}/log/${name}/${name}_uniq | awk -F ' ' '$2<$num{print $0}' > ${dir}/log/${name}.error
customer_head_tt=$(cat ${dir}/lib/customer/customer_head | head -1)
customer_head=$(cat ${dir}/log/customer/customer.dat_log | head -1)
arr=(${customer_head//,/ })
arrtt=(${customer_head_tt//,/ })
len=`echo ${customer_head} | awk -F "," "{print NF}"`
echo ${len}
echo ${#arr[*]}
echo "" > ${dir}/log/${name}/check_head.log
for((i=0;i<${#arr[*]};i++))
do
if [ "${arr[$i]}" == "${arrtt[$i]}" ]
then
 echo $i : "ok" >> ${dir}/log/${name}/check_head.log
else
 echo $i : "data "${arr[$i]} "-------->""file" ${arrtt[$i]} >> ${dir}/log/${name}/check_head.log
fi
done
}

function checkdata_doss() {
date=$1
num=17
name=doss
dir=`pwd`
echo ${dir}
#spark-submit --master local --class com.chance.checkdata.GBKToUTF_8 checkdata-1.0.jar ${dir_home}/data/${name}/${date}/${name}.csv ${dir}/log/${name}/${name}.dat_log
iconv -f GBK -t UTF-8 -c ${dir_home}/data/${name}/${date}/${name}.csv > ${dir}/log/${name}/${name}.dat_log
cat ${dir}/log/${name}/${name}.dat_log | awk -F "\",\"" '{print NF}'  > ${dir}/log/${name}/${name}_lines
cat ${dir}/log/${name}/${name}_lines | sort |uniq -c > ${dir}/log/${name}/${name}_uniq
cat ${dir}/log/${name}/${name}_uniq | awk -F ' ' '$2<$num{print $0}' > ${dir}/log/${name}.error
doss_head_tt=$(cat ${dir}/lib/doss/doss_head | head -1)
doss_head=$(cat ${dir}/log/doss/doss.dat_log | head -1)
arr=(${doss_head//,/ })
arrtt=(${doss_head_tt//,/ })
len=`echo ${doss_head} | awk -F "," "{print NF}"`
echo ${len}
echo ${#arr[*]}
echo "" > ${dir}/log/${name}/check_head.log
for((i=0;i<${#arr[*]};i++))
do
if [ "${arr[$i]}" == "${arrtt[$i]}" ]
then
 echo $i : "ok" >> ${dir}/log/${name}/check_head.log
else
 echo $i : "data "${arr[$i]} "-------->""file" ${arrtt[$i]} >> ${dir}/log/${name}/check_head.log
fi
done
}
function fun_main(){
#if [ $# = 2 ]
#then
# echo "sh $0 <function_name> [date]"
# exit 1
#fi
checkdata_claim $1
checkdata_part $1
checkdata_order $1
checkdata_customer $1
checkdata_doss $1
}
#$1 $2
#fun_main 201704_201707
fun_main $1
#checkdata_claim
#checkdata_part
#checkdata_order
#checkdata_customer
#checkdata_doss
