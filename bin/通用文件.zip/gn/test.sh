#!/bin/bash

#claim_head=$(cat ${dir}/log/claim/claim.dat_log | head -1)
claim_head=jerry,alice,davied,wendy
arr=(${claim_head//,/ })  
#arr=$(echo $claim_head | tr ',')
echo ${arr[0]}


#names=(jerry alice davied wendy)
for((i=0;i<${#arr[*]};i++))
do
	echo ${arr[$i]}
done

#a="one,two,three,four"
#OLD_IFS="$IFS" 
#IFS="," 
#arr=($a) 
#IFS="$OLD_IFS" 
#for s in ${arr[@]} 
#do 
#    echo "$s" 
#done
