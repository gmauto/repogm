#!/bin/bash

#cat doss.dat | awk -F "\",\"" '{print NF}' | sort |uniq -c > ../log/doss.log
#cat part.dat | awk -F "\",\"" '{print NF}' | sort |uniq -c > ../log/part.log
#cat order.dat | awk -F "\",\"" '{print NF}' | sort |uniq -c > ../log/order.log
#cat claim.dat | awk -F "\",\"" '{print NF}' | sort |uniq -c > ../log/claim.log
#cat customer.dat | awk -F "\",\"" '{print NF}' | sort |uniq -c > ../log/customer.log
aa=$(cat /home/hdfs/data/claim.dat | head -n 1 )
#echo ${aa/","/\t}
bb=$(echo $aa | cut -d \",\" -f 1)
#a =${file/\",\"/}
#print ${a}
#echo ${a}
