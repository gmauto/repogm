#!/bin/bash

database=ipsos_test4
local_dim_files=/home/ipsos_test4/general/data/dim
function load_data_ff(){
if [ $# -lt 1 ]
then
 echo "需要一个参数，version"
 exit -1
else
 version=$1
fi
hive -e "
use ${database};
load data local inpath '${local_dim_files}/${version}/maintnance/*' overwrite into table maintnance partition(version=${version});
load data local inpath '${local_dim_files}/${version}/enclosure/*' overwrite into table enclosure partition(version=${version});
load data local inpath '${local_dim_files}/${version}/engine_oil/*' overwrite into table engine_oil partition(version=${version});
load data local inpath '${local_dim_files}/${version}/distributor/*' overwrite into table distributor partition(version=${version});
load data local inpath '${local_dim_files}/${version}/filter/*' overwrite into table filter partition(version=${version});
load data local inpath '${local_dim_files}/${version}/doss_asc/*' overwrite into table doss_asc partition(version=${version});
load data local inpath '${local_dim_files}/${version}/sexual/*' overwrite into table sexual;
load data local inpath '${local_dim_files}/${version}/city/*' overwrite into table city;
load data local inpath '${local_dim_files}/${version}/asc_mapping/*' overwrite into table asc_mapping;
load data local inpath '${local_dim_files}/${version}/name/*' overwrite into table name;
load data local inpath '${local_dim_files}/${version}/primary_classification/*' overwrite into table primary_classification;
load data local inpath '${local_dim_files}/${version}/second_level_classification/*' overwrite into table second_level_classification;
load data local inpath '${local_dim_files}/${version}/province/*' overwrite into table province;
load data local inpath '${local_dim_files}/${version}/mapping/*' overwrite into table mapping;
load data local inpath '${local_dim_files}/mon_mapping/*' overwrite into table mon_mapping;
"
}
$1 $2

